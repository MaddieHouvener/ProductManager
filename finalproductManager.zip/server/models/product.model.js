const mongoose = require('mongoose');


const ProductSchema = new mongoose.Schema({
    title: {
        type: String,
        minlength: [3, "Title must be 3 or more characters"] 
    },

    price: { 
        type: String,
        minlength: [4, "Price must be at least 4 characters long"]
    },
    description: { type: String }
}, { timestamps: true });



module.exports.Product = mongoose.model('Product', ProductSchema);
